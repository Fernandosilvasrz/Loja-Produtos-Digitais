import React from "react";

const products = [
  {
    name: "Fone de Ouvido Bluetooth JBL",
    image: "https://m.media-amazon.com/images/I/51+Y6kWrVmL._AC_SL1000_.jpg",
    link: "https://www.amazon.com.br/dp/B08K3MHVSR?tag=produtosdi03d-20",
    price: "R$ 299,00"
  },
  {
    name: "Kindle 11ª Geração com Luz Integrada",
    image: "https://m.media-amazon.com/images/I/61Q0K8gUKlL._AC_SL1000_.jpg",
    link: "https://www.amazon.com.br/dp/B09SWXSK2W?tag=produtosdi03d-20",
    price: "R$ 449,00"
  },
  {
    name: "Echo Dot 5ª geração com Alexa",
    image: "https://m.media-amazon.com/images/I/61u48FEs2WL._AC_SL1000_.jpg",
    link: "https://www.amazon.com.br/dp/B09B8V4GX4?tag=produtosdi03d-20",
    price: "R$ 379,00"
  },
  {
    name: "Fire TV Stick com Alexa",
    image: "https://m.media-amazon.com/images/I/51Da2Z+FTQL._AC_SL1000_.jpg",
    link: "https://www.amazon.com.br/dp/B09PZ3KZJZ?tag=produtosdi03d-20",
    price: "R$ 349,00"
  },
  {
    name: "Monitor LG 24'' Full HD IPS",
    image: "https://m.media-amazon.com/images/I/71ukHhQ5KXL._AC_SL1500_.jpg",
    link: "https://www.amazon.com.br/dp/B08D6YWM43?tag=produtosdi03d-20",
    price: "R$ 799,00"
  },
  {
    name: "Teclado Mecânico Gamer Redragon",
    image: "https://m.media-amazon.com/images/I/61H44a0n90L._AC_SL1000_.jpg",
    link: "https://www.amazon.com.br/dp/B08Y1BXJ8B?tag=produtosdi03d-20",
    price: "R$ 229,00"
  }
];

export default function LojaAfiliado() {
  return (
    <div className="min-h-screen bg-white p-6">
      <h1 className="text-3xl font-bold text-center text-blue-800 mb-10">Loja de Produtos Digitais</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {products.map((product, index) => (
          <div
            key={index}
            className="bg-gray-100 p-4 rounded-2xl shadow-lg hover:shadow-xl transition"
          >
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-60 object-contain rounded-xl mb-4"
            />
            <h2 className="text-xl font-semibold text-gray-800 mb-2">
              {product.name}
            </h2>
            <p className="text-lg text-green-700 font-bold mb-4">
              {product.price}
            </p>
            <a
              href={product.link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-blue-700 text-white px-4 py-2 rounded-xl hover:bg-blue-800 transition"
            >
              Ver na Amazon
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}
